# Install: python -m pip install pandas numpy matplotlib seaborn
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = sns.load_dataset("penguins").dropna()
print(df.head())
print("\nShape:", df.shape)
print("\nSummary statistics:\n", df.describe(include="all"))
print("\nMissing values:\n", df.isnull().sum())
numeric = df.select_dtypes(include="number").columns
for col in numeric:
    sns.histplot(data=df, x=col, kde=True)
    plt.title(f"Distribution of {col}")
    plt.tight_layout()
    plt.show()
sns.countplot(data=df, x="species")
plt.title("Penguin species counts"); plt.tight_layout(); plt.show()
sns.scatterplot(data=df, x="bill_length_mm", y="bill_depth_mm", hue="species")
plt.title("Bill length vs bill depth"); plt.tight_layout(); plt.show()
sns.heatmap(df[numeric].corr(), annot=True, cmap="coolwarm")
plt.title("Correlation heatmap"); plt.tight_layout(); plt.show()
print("\nPotential target: species")
print("Potential features: bill_length_mm, bill_depth_mm, flipper_length_mm, body_mass_g")
