# Install: python -m pip install pandas
import pandas as pd
from pathlib import Path

csv_path = Path("find_s_dataset.csv")
if not csv_path.exists():
    sample = pd.DataFrame([
        ["Sunny", "Warm", "Normal", "Strong", "Warm", "Same", "Yes"],
        ["Sunny", "Warm", "High", "Strong", "Warm", "Same", "Yes"],
        ["Rainy", "Cold", "High", "Strong", "Warm", "Change", "No"],
        ["Sunny", "Warm", "High", "Strong", "Cool", "Change", "Yes"],
    ], columns=["Sky", "AirTemp", "Humidity", "Wind", "Water", "Forecast", "EnjoySport"])
    sample.to_csv(csv_path, index=False)
    print(f"Created sample dataset: {csv_path.resolve()}")

data = pd.read_csv(csv_path)
target = data.columns[-1]
positive = data[data[target].astype(str).str.lower().isin(["yes", "1", "true"])]
if positive.empty:
    raise ValueError("No positive examples found. Use Yes/No labels in the final column.")
hypothesis = positive.iloc[0, :-1].astype(str).tolist()
for _, row in positive.iloc[1:, :-1].iterrows():
    for i, value in enumerate(row.astype(str).tolist()):
        if hypothesis[i] != value:
            hypothesis[i] = "?"
print("Training data:\n", data)
print("Final most-specific hypothesis:", hypothesis)
