# Install: python -m pip install scikit-learn matplotlib
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42, stratify=data.target
)
# HistGradientBoosting is built into scikit-learn and avoids extra XGBoost setup.
model = HistGradientBoostingClassifier(random_state=42)
params = {"learning_rate": [0.05, 0.1], "max_iter": [100, 150],
          "max_leaf_nodes": [15, 31]}
search = GridSearchCV(model, params, cv=3, scoring="accuracy", n_jobs=-1)
search.fit(X_train, y_train)
pred = search.predict(X_test)
print("Best parameters:", search.best_params_)
print("Accuracy:", round(accuracy_score(y_test, pred), 4))
print(classification_report(y_test, pred))
print("Note: HistGradientBoosting does not expose feature_importances_ directly.")
print("For tree feature importance, fit RandomForestClassifier as an additional model.")
rf = RandomForestClassifier(n_estimators=200, random_state=42).fit(X_train, y_train)
indices = rf.feature_importances_.argsort()[-10:]
plt.barh(data.feature_names[indices], rf.feature_importances_[indices])
plt.title("Top 10 Feature Importances (Random Forest)")
plt.tight_layout(); plt.show()
