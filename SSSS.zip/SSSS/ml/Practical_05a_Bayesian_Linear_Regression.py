# Install: python -m pip install numpy matplotlib scikit-learn
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import BayesianRidge
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

rng = np.random.default_rng(42)
X = np.linspace(0, 10, 100).reshape(-1, 1)
y = 3.5 * X.ravel() + 5 + rng.normal(0, 2, size=100)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = BayesianRidge()
model.fit(X_train, y_train)
pred, std = model.predict(X_test, return_std=True)
print("Posterior coefficient:", model.coef_)
print("Posterior intercept:", model.intercept_)
print("MSE:", round(mean_squared_error(y_test, pred), 3))
print("R2:", round(r2_score(y_test, pred), 3))
order = np.argsort(X_test.ravel())
plt.scatter(X_test, y_test, label="Observed")
plt.plot(X_test[order], pred[order], label="Posterior mean")
plt.fill_between(X_test.ravel()[order], (pred - 2*std)[order],
                 (pred + 2*std)[order], alpha=0.2, label="Approx. 95% interval")
plt.legend(); plt.title("Bayesian Linear Regression"); plt.show()
