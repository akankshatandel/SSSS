# Install: python -m pip install numpy pandas scikit-learn
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.feature_selection import SelectKBest, f_regression

df = pd.DataFrame({
    "Area": [800, 900, 1000, 1100, 1200, 1300, 1400, 1500, 1600, 1700],
    "Bedrooms": [1, 2, 2, 2, 3, 3, 3, 4, 4, 4],
    "Age": [20, 18, 15, 14, 12, 10, 9, 7, 5, 3],
    "Price": [35, 42, 48, 53, 61, 68, 72, 82, 90, 98]
})
X, y = df.drop(columns="Price"), df["Price"]
selector = SelectKBest(score_func=f_regression, k=2)
X_selected = selector.fit_transform(X, y)
selected_names = X.columns[selector.get_support()].tolist()
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)
model = LinearRegression().fit(X_train, y_train)
pred = model.predict(X_test)
print("Selected features:", selected_names)
print("Coefficients:", model.coef_)
print("Intercept:", model.intercept_)
print("MSE:", mean_squared_error(y_test, pred))
print("R-squared:", r2_score(y_test, pred))
print("Note: For real datasets, inspect feature correlations/VIF for multicollinearity.")
