# Install: python -m pip install scikit-learn matplotlib
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
from sklearn.mixture import GaussianMixture

X, _ = make_blobs(n_samples=300, centers=3, cluster_std=0.8, random_state=42)
gmm = GaussianMixture(n_components=3, covariance_type="full", random_state=42)
labels = gmm.fit_predict(X)
print("Means of Gaussian components:\n", gmm.means_)
print("BIC:", round(gmm.bic(X), 2))
print("AIC:", round(gmm.aic(X), 2))
plt.scatter(X[:, 0], X[:, 1], c=labels, s=25)
plt.scatter(gmm.means_[:, 0], gmm.means_[:, 1], marker="X", s=200)
plt.title("Gaussian Mixture Model Clustering")
plt.xlabel("Feature 1"); plt.ylabel("Feature 2"); plt.show()
